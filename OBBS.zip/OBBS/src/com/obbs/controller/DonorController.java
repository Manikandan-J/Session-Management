package com.obbs.controller;

import java.util.ArrayList;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.obbs.exception.ApplicationException;
import com.obbs.model.BloodGroupPojo;
import com.obbs.model.DonorPojo;
import com.obbs.model.FeedbackPojo;
import com.obbs.model.PostBloodRequirementPojo;
import com.obbs.model.SlotBookingPojo;
import com.obbs.model.StatesPojo;
import com.obbs.service.DonorService;
import com.obbs.service.UsersService;

@Controller
public class DonorController {
	@Autowired
	DonorService donorService;
	@Autowired
	UsersService usersService;
	public static Logger logger = Logger.getLogger("OBBS");

	@RequestMapping(value="/donorLogin", method = RequestMethod.GET)

	public String donorLogin(@ModelAttribute("command") DonorPojo donorPojo, BindingResult result,HttpServletRequest request, HttpServletResponse response) {
		int donorId;
		ModelAndView mav =null;
		String url = null;
		try {
			donorId = donorService.donorLogin(donorPojo);
			if (donorId != 0) {
				
				HttpSession session=request.getSession();
				session.setAttribute("donorId",donorId);
				url="redirect:/donorSessionCheck";
				
				
				} 
			 else
			 {		
				 mav= new ModelAndView("DonorLogin");
				mav.addObject("invalid", "Invalid credentials.Please try again!");
		}
		}
			catch (ApplicationException e) {
			logger.error(e);

		}

		return url;

	}
	@RequestMapping(value = "/donorSessionCheck", method = RequestMethod.GET)
	public ModelAndView donorSessionCheck( HttpServletRequest request, HttpServletResponse response) {
		int donorId;
		ModelAndView mav =null;
		HttpSession session=request.getSession(false);
		try {
			System.out.println("*************");
			donorId=(int)(session.getAttribute("donorId"));
			System.out.println(session.getAttribute("donorId"));
			
				if(donorId!=0) {
				    List<PostBloodRequirementPojo> requirementList = new ArrayList<PostBloodRequirementPojo>();
				    requirementList = donorService.displayRequirements();
					  if (requirementList != null) {
						mav=new ModelAndView("DonorBooking");
						mav.addObject("requirementList", requirementList);
						request.setAttribute("donorId", donorId);
					  }
				
			  }
			 else
			 {		
				 mav= new ModelAndView("Home");
				
		      }
		}
		catch (Exception e) {
			logger.error(e);
			System.out.println("wwww");
			 mav= new ModelAndView("Home");
            }

		return mav;

	}

	@RequestMapping(value="/donorRequests",  method = RequestMethod.POST)

	public ModelAndView donorRequests(@ModelAttribute("command") DonorPojo donorPojo, BindingResult result) {
		int id;
		ModelAndView mav =null;
		try {
			id = donorService.registerDonor(donorPojo);
			if (id == 1) {
				
				mav = new ModelAndView("DonorLogin");
				mav.addObject("d_msg","Successfully registered as a donor"); 
				
			} else {
				
				mav = new ModelAndView("DonorRegister");
				mav.addObject("d_msg","Fill the missed fields"); 
				//return new ModelAndView("DonorRegister");
				
			}

		} catch (ApplicationException e) {

			logger.error(e);
			mav= new ModelAndView("Error");

		}
		
return mav;
	}
	

	@RequestMapping(value="/slotBooking", method = RequestMethod.GET)
	public ModelAndView slotBooking(@ModelAttribute("command")  SlotBookingPojo  slotBookingPojo, BindingResult mapping1BindingResult,HttpServletRequest request, HttpServletResponse response)  {
		ModelAndView mav=null;
		HttpSession session=request.getSession(false);
		try {
		if((int)session.getAttribute("donorId")!=0) {
	     System.out.println("slotBooking");	
	  
		int i = slotBookingPojo.getDonorId();
		System.out.println(i);
		System.out.println("slotBooking");
		mav = new ModelAndView("BookingForm");
		mav.addObject("slotBookingPojo", slotBookingPojo);
		}
		}catch(Exception e) {
			mav = new ModelAndView("Home");
		}
		return mav;
	}

	@RequestMapping(value="/confirmSlot", method = RequestMethod.GET)
	public ModelAndView confirmSlot(@ModelAttribute("command") SlotBookingPojo slotBookingPojo, BindingResult result,
			HttpServletRequest request, HttpServletResponse response) {
		int recipientId, delete;
		HttpSession session=request.getSession(false);
		ModelAndView mav =null;
		
		try {
			if((int)session.getAttribute("donorId")!=0) {
			recipientId = donorService.confirmSlot(slotBookingPojo);
			if (recipientId != 0) {
				delete = donorService.deleteRequirement(recipientId);
				if (delete != 0) {
					mav= new ModelAndView("SlotConfirmation");
				}

				else {
					mav=new ModelAndView("Error");
				}

			}
		}
		}catch (Exception e) {
			logger.error(e);
			mav=new ModelAndView("Home");

		}
		return mav;

	}
	@RequestMapping("/feedback")

	public ModelAndView feedback(@ModelAttribute("command") FeedbackPojo feedbackPojo, BindingResult result) {
		int id;
		id = donorService.feedbackEntry(feedbackPojo);
		if (id == 1) {
			return new ModelAndView("Home");
		} else {
			return new ModelAndView("Error");
		}

	}
	@RequestMapping("/feedbackFetch")

	public ModelAndView feedbackFetch(@ModelAttribute("feedback") FeedbackPojo feedbackPojo,
			BindingResult result, HttpServletRequest request, HttpServletResponse response) {

		List<FeedbackPojo> details = new ArrayList<FeedbackPojo>();
		details = donorService.feedbackFetch(feedbackPojo);
		request.setAttribute("details", details);

		if (!details.isEmpty()) {
			return new ModelAndView("FeedbackDetails");
			
		} else {
			return new ModelAndView("Error");
		}

	}


	@RequestMapping(value = "/donorSignIn", method = RequestMethod.GET)
	public ModelAndView donorSignIn(HttpServletRequest request, HttpServletResponse response) {

		return new ModelAndView("DonorLogin");
	}

	@RequestMapping(value = "/donorRegister", method = RequestMethod.GET)
	public ModelAndView donorRegister(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav=null;
		try {
			List<StatesPojo> allStates = usersService.getAllStates();
			List<BloodGroupPojo> allBloodGroups = usersService.getAllBloodGroups();
			mav =  new ModelAndView("Donor");
			mav.addObject("allStates",allStates);
			mav.addObject("allBloodGroups",allBloodGroups);
		} catch (ApplicationException e) {
			logger.error(e);
			mav =  new ModelAndView("Error");
		}
		
		
		
		return mav;
	}
	@RequestMapping(value = "/donorLogout", method = RequestMethod.GET)
	public ModelAndView donorLogout(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView model = new ModelAndView();
			HttpSession session = request.getSession();
			session.invalidate();
			model.addObject("message", "Logged out successfully.");

		
		return new ModelAndView("Home");
	}
	@RequestMapping(value = "/feedbackPage", method = RequestMethod.GET)
	public ModelAndView feedbackPage(HttpServletRequest request, HttpServletResponse response) {

		return new ModelAndView("Feedback");
	}


}
